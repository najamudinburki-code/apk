import { io } from "socket.io-client";

// Backend endpoint for the management server.
// Override in a .env file: VITE_SOCKET_URL=https://mdm.your-company.internal
const URL = import.meta.env.VITE_SOCKET_URL || "http://localhost:4000";

export const socket = io(URL, {
  autoConnect: false,            // we connect explicitly from <App/>
  transports: ["websocket"],
  withCredentials: true,         // send the admin session cookie / auth
});
