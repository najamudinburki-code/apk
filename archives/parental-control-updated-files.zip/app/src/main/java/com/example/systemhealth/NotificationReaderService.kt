package com.example.systemhealth

import android.app.Notification
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

// Manifest: exported="true", permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE";
// intent-filter action="android.service.notification.NotificationListenerService".
// The device user must explicitly enable Notification Access in Android Settings.
class NotificationReaderService : NotificationListenerService() {
    private val handler = Handler(Looper.getMainLooper())

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        // Android 6 does not guarantee that this callback runs on the main thread.
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { processNotification(sbn) }
            return
        }
        processNotification(sbn)
    }

    private fun processNotification(sbn: StatusBarNotification) {
        val packageName = sbn.packageName
        if (packageName == "android" || packageName.startsWith("com.android.") ||
            packageName == applicationContext.packageName) return
        try {
            if (!ParentalCapture.permits(this, packageName)) return
            val notification = sbn.notification ?: return
            if (notification.category == Notification.CATEGORY_SYSTEM) return
            val extras = notification.extras ?: return
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
                ?.takeIf { it.isNotBlank() }
                ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
            if (title.isBlank() && text.isBlank()) return

            val payload = JSONObject()
                .put("package", packageName)
                .put("title", title)
                .put("text", text)
                .put("timestamp", utcTimestamp(sbn.postTime))
            ParentalCapture.deliver(payload)
        } catch (_: RuntimeException) {
            // Ignore malformed extras; never log notification contents.
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
