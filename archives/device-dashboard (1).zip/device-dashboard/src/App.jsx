import { useEffect, useState } from "react";
import { socket } from "./socket";
import MapView from "./components/MapView";
import SystemLogs from "./components/SystemLogs";
import FileManager from "./components/FileManager";
import ControlPanel from "./components/ControlPanel";

const NAV = [
  { key: "map", label: "Device Map", icon: MapIcon },
  { key: "logs", label: "System Logs", icon: LogIcon },
  { key: "files", label: "File Manager", icon: FileIcon },
  { key: "control", label: "Control Panel", icon: ControlIcon },
];

export default function App() {
  const [view, setView] = useState("map");
  const [connected, setConnected] = useState(socket.connected);
  const [devices, setDevices] = useState([]); // enrolled devices roster

  useEffect(() => {
    function onConnect() {
      setConnected(true);
      socket.emit("admin:subscribe"); // ask server for roster + live feeds
    }
    function onDisconnect() {
      setConnected(false);
    }
    function onRoster(list) {
      setDevices(Array.isArray(list) ? list : []);
    }

    socket.on("connect", onConnect);
    socket.on("disconnect", onDisconnect);
    socket.on("devices:roster", onRoster);

    socket.connect();

    return () => {
      socket.off("connect", onConnect);
      socket.off("disconnect", onDisconnect);
      socket.off("devices:roster", onRoster);
      socket.disconnect();
    };
  }, []);

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100">
      {/* Sidebar */}
      <aside className="flex w-64 flex-col border-r border-slate-800 bg-slate-900">
        <div className="flex items-center gap-2 px-5 py-5 border-b border-slate-800">
          <div className="h-8 w-8 rounded-lg bg-indigo-500/20 ring-1 ring-indigo-400/40 flex items-center justify-center">
            <span className="text-indigo-300 text-sm font-bold">MDM</span>
          </div>
          <div>
            <p className="text-sm font-semibold leading-tight">Fleet Console</p>
            <p className="text-[11px] text-slate-400 leading-tight">
              Device Management
            </p>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1">
          {NAV.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setView(key)}
              className={`group flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition
                ${
                  view === key
                    ? "bg-indigo-500/15 text-indigo-200 ring-1 ring-inset ring-indigo-400/30"
                    : "text-slate-300 hover:bg-slate-800/70 hover:text-white"
                }`}
            >
              <Icon className="h-4 w-4 shrink-0" />
              {label}
            </button>
          ))}
        </nav>

        <div className="border-t border-slate-800 px-4 py-4">
          <div className="flex items-center gap-2 text-xs">
            <span
              className={`h-2 w-2 rounded-full ${
                connected ? "bg-emerald-400" : "bg-rose-500"
              }`}
            />
            <span className="text-slate-400">
              {connected ? "Connected" : "Disconnected"}
            </span>
          </div>
          <p className="mt-1 text-[11px] text-slate-500">
            {devices.length} enrolled device{devices.length === 1 ? "" : "s"}
          </p>
        </div>
      </aside>

      {/* Main */}
      <main className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-slate-800 bg-slate-900/60 px-6 py-4 backdrop-blur">
          <h1 className="text-lg font-semibold">
            {NAV.find((n) => n.key === view)?.label}
          </h1>
          <span
            className={`rounded-full px-3 py-1 text-xs font-medium ${
              connected
                ? "bg-emerald-500/10 text-emerald-300 ring-1 ring-inset ring-emerald-400/30"
                : "bg-rose-500/10 text-rose-300 ring-1 ring-inset ring-rose-400/30"
            }`}
          >
            {connected ? "Live" : "Offline"}
          </span>
        </header>

        <section className="min-h-0 flex-1 overflow-auto">
          {view === "map" && <MapView devices={devices} />}
          {view === "logs" && <SystemLogs />}
          {view === "files" && <FileManager devices={devices} />}
          {view === "control" && <ControlPanel devices={devices} />}
        </section>
      </main>
    </div>
  );
}

/* --- Inline icons (no icon dependency required) --- */
function MapIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...props}>
      <path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2Z" />
      <path d="M9 4v14M15 6v14" />
    </svg>
  );
}
function LogIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...props}>
      <path d="M4 5h16M4 10h16M4 15h10M4 20h7" />
    </svg>
  );
}
function FileIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...props}>
      <path d="M4 6a2 2 0 0 1 2-2h5l2 2h5a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6Z" />
    </svg>
  );
}
function ControlIcon(props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...props}>
      <circle cx="12" cy="12" r="3" />
      <path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2" />
    </svg>
  );
}
