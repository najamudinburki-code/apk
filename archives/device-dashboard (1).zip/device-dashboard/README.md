# Fleet Console — Device Management Dashboard

Dark-mode React admin console (Vite + Tailwind + Leaflet + Socket.IO) for an
enterprise MDM/RMM backend. Intended for **enrolled, operator-managed devices**
where the device owner has consented to management — not covert monitoring.

## Install & run

```bash
npm install
# point at your management backend:
echo "VITE_SOCKET_URL=http://localhost:4000" > .env
npm run dev
```

## Socket.IO contract (what the frontend expects the backend to provide)

Client → server:
- `admin:subscribe` — request roster + feeds after auth
- `map:subscribe` / `map:unsubscribe`
- `logs:subscribe` / `logs:unsubscribe`
- `files:list` → `{ deviceId, path }`
- `command:send` → `{ command: "request_screenshot" | "request_status", deviceId, requestedAt }`

Server → client:
- `devices:roster` → `[{ id, name, online }]`
- `device:location` → `{ id, name, lat, lng, accuracy?, timestamp }`
- `system:log` → `{ level: "info|success|warn|error", source, message, timestamp }`
- `files:listing` → `{ deviceId, path, entries:[{ name, type, size, modified }] }`
- `command:ack` → `{ command, deviceId, ok, detail, timestamp }`

## Files

- `src/App.jsx` — layout, sidebar nav, socket lifecycle, connection state
- `src/components/MapView.jsx` — Leaflet map, live GPS markers
- `src/components/SystemLogs.jsx` — streaming event log with level filter
- `src/components/FileManager.jsx` — remote directory browser
- `src/components/ControlPanel.jsx` — screenshot / status request buttons
- `src/socket.js` — Socket.IO client singleton
```
